<!DOCTYPE html>
<html>
    <head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
    </head>
<body>
Calculater
<?php
$x = 5;
$y = 4;

echo "Please enter your choice";

echo "1.Addition"."<br>";
echo "2.Substraction";
echo "3.Division";
echo "4.Multiplication";


echo $x + $y;
echo $x - $y;
echo $x / $y;
echo $x * $y;
?>

</body>
</html>
